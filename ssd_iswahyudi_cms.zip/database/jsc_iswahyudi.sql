/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.5.5-10.4.13-MariaDB : Database - jsc_iswahyudi
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`jsc_iswahyudi` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `jsc_iswahyudi`;

/*Table structure for table `jsc_auth` */

DROP TABLE IF EXISTS `jsc_auth`;

CREATE TABLE `jsc_auth` (
  `id` bigint(16) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

/*Data for the table `jsc_auth` */

insert  into `jsc_auth`(`id`,`username`,`password`,`phone_number`) values (1,'yudi','c232864d5de2064450915c0b9e4cc0b5','085282080835'),(2,'iswah','7e2d629c0d54a4f7060cca2133aed7ec','088');

/*Table structure for table `jsc_faskes` */

DROP TABLE IF EXISTS `jsc_faskes`;

CREATE TABLE `jsc_faskes` (
  `id` bigint(16) NOT NULL AUTO_INCREMENT,
  `nama_faskes` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `nomor_telepon` varchar(20) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

/*Data for the table `jsc_faskes` */

insert  into `jsc_faskes`(`id`,`nama_faskes`,`alamat`,`nomor_telepon`,`latitude`,`longitude`) values (1,'Rumah Sakit Islam Jakarta','Jl. Cempaka Putih Tengah I / 1','021 42801567',-6.16912,106.871016),(2,'Rumah Sakit Pertamina Jaya','Jl. Achmad Yani No. 2, By Pass','021 4211911',-6.172976,106.876041),(3,'Rumah Sakit Tarakan','Jl. Kyai Caringin No. 7','021 3503003, 021 350',-6.171488,106.810391),(4,'Rumah Sakit Mitra Kemayoran','Jl. Landas Pacu Timur','021 6545555',-6.151736,106.8585),(5,'Rumah Sakit PGI Cikini','Jl. Raden Saleh No. 40 ','021 38997777',-6.19135,106.841931),(6,'Rumah Sakit Abdi Waluyo','Jl. HOS Cokroaminoto No. 31 - 33','021 3144989',-6.189611,106.829304),(7,'Rumah Sakit Menteng Mitra Afia','Jl. Kali Pasir  No. 9','021 3154050',-6.186767,106.83839),(8,'Rumah Sakit Husada ','Jl. Raya Mangga Besar Raya 137 / 139','021 6260208, 021 649',-6.147263,106.82947),(9,'Rumah Sakit Dr. Cipto Mangunkusumo','Jl. Diponegoro No. 71','021 391830113, 021 3',-6.196907,106.846826),(10,'Rumah Sakit Moh. Ridwan Meuraksa','Jl. Kramat Raya No. 17 A','021 3150535, 021 323',-6.1805365687186,106.84298635003874),(11,'Rumah Sakit Kramat 128','Jl. Kramat Raya No. 128','021 3909513, 021 390',-6.18522,106.844045),(12,'Rumah Sakit PK. Sint Carolus ','Jl. Salemba Raya No. 41','021 3904441',-6.195265,106.851339),(13,'Rumah Sakit Moh. Husni Thamrin Internasional Salemba','Jl. Salemba Tengah 26 - 28','021 3904422 Ext.1900',-6.193385,106.851903),(14,'Rumah Sakit Gatot Subroto','Jl. Dr. Abdul Rachman Saleh 24','021 3441008',-6.175926,106.837611),(15,'Rumah Sakit DR. Mintohardjo','Jl. Bendungan Hilir No. 17','021 5703081, 021 570',-6.210536,106.811422),(16,'Rumah Sakit Evasari','Jl. Rawamangun No. 47','021 4202851, 021 420',-6.193363,106.859517),(17,'Rumah Sakit Budi Kemuliaan ','Jl. Budi Kemuliaan No. 25 ','021 3842828',-6.180392,106.818194),(18,'Rumah Sakit Profesor Nizar ','Jl. Kesehatan No. 9','021 3843596, 021 350',-6.171197,106.815228),(19,'Rumah Sakit Dharma Sakti','Jl. Kaji No. 40','021 63864375, 021 63',-6.168423,106.81522),(20,'Rumah Sakit Panti Raharja','Jl. Sawo No. 58 - 60','021 3906914, 021 319',-6.195183,106.835091),(21,'a','a','0',3,2);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
