<?php
class Beranda extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model("Model_security");
		$this->load->model("Login_model");
	}

	public function admin()
	{
		$this->Model_security->getSecSup();
		$this->Model_security->logSecSup();
		$data['datamenu'] = [];//$this->Model_data->DataMenu('1');
		
		$this->load->view("backend/sup/header");
		$this->load->view("backend/sup/nav", $data);
		$this->load->view("backend/sup/dashboard"); //, $data
		$this->load->view("backend/sup/footer-data");
	}

}