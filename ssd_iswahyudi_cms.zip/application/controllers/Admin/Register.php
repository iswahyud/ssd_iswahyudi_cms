<?php
class Register extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('text');
		$this->load->helper('email');
	}

	public function index()
	{
		$this->load->view("backend/sup/Register_view");
	}

	public function verif()
	{
		$this->load->view("backend/sup/Verification_view");
	}

	public function proses()
	{
		$p1 = $this->input->post('pass1');
		$p2 = $this->input->post('pass2');
		$username = $this->input->post('username');
		$phone_number = $this->input->post('phone_number');
		$cekUsr = $this->Model_data->checkuserByUsername($username);
		$encrypt = md5($p2);

		$data = array(
							            'username' 	=> set_value('username'),
										'password'		=> $encrypt,
										'phone_number' 	=> set_value('phone_number')
							        );

		//cek password 
		if($p1 != $p2)
		{
			$this->session->set_flashdata('nomatch', '&nbsp;');
			redirect('register', $data);
		}
		else
		{
			//cek user di database
			if($cekUsr->num_rows() == 0 || $cekMail->num_rows() == 0)
			{
				
					$insertUserData = $this->Model_data->AddUser($data);

		            if($insertUserData == TRUE)
		        	{
		        		$datas['pesan'] = ""; 		
						$this->load->view("backend/sup/Verification_view", $datas);	   		        		

		            }
		       		else
		        	{
		        		$this->session->set_flashdata('error_dft', '&nbsp;');
		        		redirect('register', $data);
		            }
				
	        	
	        }
	        else
	        {
	        	$this->session->set_flashdata('notavailable', '&nbsp;');
		       	redirect('register', $data);
	        } //end validasi username
			
		}
	}

}