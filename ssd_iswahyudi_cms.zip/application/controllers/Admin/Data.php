<?php
class Data extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('text');
	}

	public function index()
	{
		$this->Model_security->GetSecSup();
		$this->Model_security->logSecSup();
		redirect('Beranda/Admin');
	}

	public function Page($direktori)
	{
		$this->Model_security->GetSecSup();
		$this->Model_security->logSecSup();
		
		$data['datamenu'] = $this->Model_data->DataMenuByStatus('1');
		$data['hasil'] = $this->Model_data->MenuDetail($direktori);

		$this->load->view("backend/sup/header");
		$this->load->view("backend/sup/nav", $data);
		$this->load->view('backend/sup/DetailMenu', $data);
		$this->load->view("backend/sup/footer-data");
	}

	//user
	function User()
	{
		$this->Model_security->getSecSup();
		$this->Model_security->logSecSup();
		$data['datamenu'] = [];
		$data['hasil'] = $this->Model_data->DataUser();

		$this->load->view("backend/sup/header");
		$this->load->view("backend/sup/nav", $data);
		$this->load->view('backend/sup/DataUser', $data);
		$this->load->view("backend/sup/footer-data");
	}

	function EditUser($id)
	{
		$this->Model_security->getSecSup();
		$this->Model_security->logSecSup();
		
		$hasil1 = $this->Model_data->EditUser($id);

		if ($hasil1->num_rows()>0)
		   {		 
			 $hasil=$hasil1->row();  	     
			 $data["id"]		=	$hasil->id;
			 $data["username"]	=	$hasil->username;
			 $data["phone_number"]	=	$hasil->phone_number;
			 
		   }
		else
		   {
				$data["id"]		=	"";
				$data["username"]	=	"";
				$data["phone_number"]	=	"";
		   }

		$this->load->view("backend/sup/header");
		$data['datamenu'] = [];
		$this->load->view("backend/sup/nav", $data);
		$this->load->view('backend/sup/EditUser', $data);
		$this->load->view("backend/sup/footer-data");
	}

	function proses_user($id)
	{
		$username = $this->input->post('username');
		//$cekUsr = $this->Model_data->checkuserByUsername($username);

		$data = array(
			'id'		=> set_value('id'),
			'username' 		=> set_value('username'),
			'phone_number' 	=> set_value('phone_number')
		);

		// if($cekUsr->num_rows() == 0)
		// {
			$insertUserData = $this->Model_data->prosesuser($id,$data);

			if(!$insertUserData)
				{
					$this->session->set_flashdata('info', ' ');
					redirect('Admin/Data/user');

				}
			else
				{
					$this->session->set_flashdata('error', ' ');
					redirect('Admin/Data/user');
					
				}
		// }
		// else
		// {
		// 	$this->session->set_flashdata('notavailable', ' ');
		// 	$this->load->view("backend/sup/header");
		// 	$data['datamenu'] = [];
		// 	$this->load->view("backend/sup/nav", $data);
		// 	$this->load->view('backend/sup/EditUser', $data);
		// 	$this->load->view("backend/sup/footer-data");
			
		// }
	}

	function TambahUser()
	{
		$this->Model_security->getSecSup();
		$this->Model_security->logSecSup();

		$this->load->view("backend/sup/header");
		$data['datamenu'] = [];
		$this->load->view("backend/sup/nav", $data);
		$this->load->view('backend/sup/AddUser');
		$this->load->view("backend/sup/footer-data");
	}

	function simpan_user()
	{
		$p1 = $this->input->post('pass1');
		$p2 = $this->input->post('pass2');
		$encrypt = md5($p2);

		if($p1 != $p2)
		{
			$data = array(
			            'username' 		=> set_value('username'),
						'password'		=> $encrypt,
						'phone_number' 	=> set_value('phone_number')
			        );

			$this->session->set_flashdata('nomatch', ' ');
			redirect('Admin/Data/tambahuser', $data);
		}
		else
		{
			$user = array(
				'username' 		=> set_value('username'),
				'password'		=> $encrypt,
				'phone_number' 	=> set_value('phone_number')
			);

        	$insertUserData = $this->Model_data->AddUser($user);

            if($insertUserData == TRUE)
	        	{
	        		$this->session->set_flashdata('info', '&nbsp;');
	        		redirect('Admin/Data/user');
	            }
	        else
	        	{
	        		$this->session->set_flashdata('error', 'Pastikan Anda Mengisi Data Secara Lengkap.');
	        		redirect('Admin/Data/tambahuser', $data);
	            }
		}
	}

	function HapusUser($id)
	{
		$this->Model_security->getSecSup();
		$this->Model_security->logSecSup();
		$hasil1 = $this->Model_data->EditUser($id);

		if ($hasil1->num_rows()>0)
		   {		 
			 $hasil=$hasil1->row();  	     
			 $data["id"]		=	$hasil->id;
			 $data["username"]	=	$hasil->username;
			 $data["phone_number"]	=	$hasil->phone_number;
			 
		   }
		else
		   {
			$data["id"]		=	"";
			$data["username"]	=	"";
			$data["phone_number"]	=	"";
		   }

		$this->load->view("backend/sup/header");
		$data['datamenu'] = [];
		$this->load->view("backend/sup/nav", $data);
		$this->load->view('backend/sup/HapusUser', $data);
		$this->load->view("backend/sup/footer-data");
	}

	function hapus_user($id)
	{
		$deleteData = $this->Model_data->hapususer($id);

		if($deleteData == TRUE)
			{
				$this->session->set_flashdata('info', ' ');
				redirect('Admin/Data/user');

			}
		else
			{
				$this->session->set_flashdata('errordel', ' ');
				redirect('Admin/Data/user');
				
			}
	}

	//Faskes
	function Faskes()
	{
		$this->Model_security->getSecSup();
		$this->Model_security->logSecSup();
		$data['datamenu'] = [];
		$data['hasil'] = $this->Model_data->DataFaskes();

		$this->load->view("backend/sup/header");
		$this->load->view("backend/sup/nav", $data);
		$this->load->view('backend/sup/DataFaskes', $data);
		$this->load->view("backend/sup/footer-data");
	}

	function EditFaskes($id)
	{
		$this->Model_security->getSecSup();
		$this->Model_security->logSecSup();
		
		$hasil1 = $this->Model_data->EditFaskes($id);

		if ($hasil1->num_rows()>0)
		   {		 
			 $hasil=$hasil1->row();  	     
			 $data["id"]		=	$hasil->id;
			 $data["nama_faskes"]	=	$hasil->nama_faskes;
			 $data["alamat"]	=	$hasil->alamat;
			 $data["nomor_telepon"]	=	$hasil->nomor_telepon;
			 $data["latitude"]	=	$hasil->latitude;
			 $data["longitude"]	=	$hasil->longitude;
			 
		   }
		else
		   {
				$data["id"]		=	"";
				$data["nama_faskes"]	=	"";
				$data["alamat"]	=	"";
			 	$data["nomor_telepon"]	=	"";
				$data["latitude"]	=	"";
				$data["longitude"]	=	"";
		   }

		$this->load->view("backend/sup/header");
		$data['datamenu'] = [];
		$this->load->view("backend/sup/nav", $data);
		$this->load->view('backend/sup/EditFaskes', $data);
		$this->load->view("backend/sup/footer-data");
	}

	function proses_faskes($id)
	{
		$data = array(
			'id'			=> set_value('id'),
			'nama_faskes'	=> set_value('nama_faskes'),
			'alamat' 		=> set_value('alamat'),
			'nomor_telepon' => set_value('nomor_telepon'),
			'latitude' => set_value('latitude'),
			'longitude' => set_value('longitude')
		);

		$lat = $this->input->post('latitude');
		$long = $this->input->post('longitude');
		$patternLat = "/^-6/i";
		$patternLong = "/(^[160-170])/";
		
		if(preg_match($patternLat, $lat) == 1 || preg_match($patternLong, $long) == 1)
		{
			$insertUserData = $this->Model_data->prosesfaskes($id,$data);

			if(!$insertUserData)
			{
				$this->session->set_flashdata('info', ' ');
				redirect('Admin/Data/faskes');

			}
			else
			{
				$this->session->set_flashdata('error', ' ');
				redirect('Admin/Data/faskes');
				
			}

		}
		else
		{
			//latitude / longitude not valid
			$this->session->set_flashdata('error', ' latitude / longitude not valid ');
			redirect('Admin/Data/faskes');
		}
		
	}

	function TambahFaskes()
	{
		$this->Model_security->getSecSup();
		$this->Model_security->logSecSup();

		$this->load->view("backend/sup/header");
		$data['datamenu'] = [];
		$this->load->view("backend/sup/nav", $data);
		$this->load->view('backend/sup/AddFaskes');
		$this->load->view("backend/sup/footer-data");
	}

	function simpan_faskes()
	{
		$data = array(
			'nama_faskes'	=> set_value('nama_faskes'),
			'alamat' 		=> set_value('alamat'),
			'nomor_telepon' => set_value('nomor_telepon'),
			'latitude' => set_value('latitude'),
			'longitude' => set_value('longitude')
		);

		$lat = $this->input->post('latitude');
		$long = $this->input->post('longitude');
		$patternLat = "/^-6/i";
		$patternLong = "/(^[160-170])/";
		
		if(preg_match($patternLat, $lat) || preg_match($patternLong, $long))
		{
			$insertFaskesData = $this->Model_data->AddFaskes($data);

			if($insertFaskesData == TRUE)
			{
				$this->session->set_flashdata('info', '&nbsp;');
				redirect('Admin/Data/faskes');
			}
			else
			{
				$this->session->set_flashdata('error', 'Pastikan Anda Mengisi Data Secara Lengkap.');
				redirect('Admin/Data/tambahfaskes', $data);
			}

		}
		else
		{
			//long-lat not valid
			$this->session->set_flashdata('error', 'long/lat not valid.');
			redirect('Admin/Data/tambahfaskes', $data);
		}

		
		
	}

	function HapusFaskes($id)
	{
		$this->Model_security->getSecSup();
		$this->Model_security->logSecSup();
		$hasil1 = $this->Model_data->EditFaskes($id);

		if ($hasil1->num_rows()>0)
		   {		 
			 $hasil=$hasil1->row();  	     
			 $data["id"]		=	$hasil->id;
			 $data["nama_faskes"]	=	$hasil->nama_faskes;
			 $data["alamat"]	=	$hasil->alamat;
			 $data["nomor_telepon"]	=	$hasil->nomor_telepon;
			 $data["latitude"]	=	$hasil->latitude;
			 $data["longitude"]	=	$hasil->longitude;
			 
		   }
		else
		   {
			 $data["id"]		=	"";
			 $data["nama_faskes"]	=	"";
			 $data["alamat"]	=	"";
			 $data["nomor_telepon"]	=	"";
			 $data["latitude"]	=	"";
			 $data["longitude"]	=	"";
		   }

		$this->load->view("backend/sup/header");
		$data['datamenu'] = [];
		$this->load->view("backend/sup/nav", $data);
		$this->load->view('backend/sup/HapusFaskes', $data);
		$this->load->view("backend/sup/footer-data");
	}

	function hapus_faskes($id)
	{
		$deleteData = $this->Model_data->hapusfaskes($id);

		if($deleteData == TRUE)
			{
				$this->session->set_flashdata('info', ' ');
				redirect('Admin/Data/faskes');

			}
		else
			{
				$this->session->set_flashdata('errordel', ' ');
				redirect('Admin/Data/faskes');
				
			}
	}

} 	
