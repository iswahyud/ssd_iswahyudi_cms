<?php
class Auth extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$this->load->view("backend/sup/Login_view");
	}

	public function proses()
	{
		$data = array('username' => $this->input->post('vuser', TRUE),
						'password' => md5($this->input->post('vpass', TRUE))
			);
		$this->load->model('Login_model'); // load model_user
		$hasil = $this->Login_model->cek_user($data);
		
				if ($hasil->num_rows() == 1) 
				{
					foreach ($hasil->result() as $sess) 
					{
						$sess_data['logged_in'] = 'Sudah Loggin';
						$sess_data['id'] = $sess->id;
						$sess_data['username'] = $sess->username;
						$sess_data['password'] = $sess->password;
						$sess_data['phone_number'] = $sess->phone_number;
						$sess_data['level'] = '0';
						$this->session->set_userdata($sess_data);
					}

					redirect("Beranda/admin");

				}
				else 
				{
					$this->session->set_flashdata('infopass', '&nbsp;');
					redirect("operator");
				}
		
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect("operator");
	}
}
?>