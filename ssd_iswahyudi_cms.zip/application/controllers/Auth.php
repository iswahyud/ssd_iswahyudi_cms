<?php
class Auth extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model("Model_security");
		$this->load->model("Login_model");
	}

	public function index()
	{
		$this->load->view("Login_view");
	}

	public function proses()
	{

		$data = array('user' => $this->input->post('vuser', TRUE),
						'pass' => md5($this->input->post('vpass', TRUE))
			);
		$hasil = $this->Login_model->cek_user($data);
		if ($hasil->num_rows() == 1) {
			foreach ($hasil->result() as $sess) {
				$sess_data['logged_in'] = 'Sudah Loggin';
				$sess_data['id'] = $sess->id;
				$sess_data['user'] = $sess->user;
				$sess_data['nama'] = $sess->nama;
				$sess_data['pass'] = $sess->pass;
				$sess_data['level'] = $sess->level;
				$sess_data['status'] = $sess->status;
				$sess_data['verifikasi'] = $sess->verifikasi;
				$this->session->set_userdata($sess_data);
			}
			if ($this->session->userdata('status')=='1') {
				$this->session->set_flashdata('blokir', '&nbsp;');
				redirect("user");
			}
			else
			{
				if ($this->session->userdata('level')=='0') {
					/*$this->session->set_flashdata('infakses', '&nbsp;');
					redirect("user");*/
					redirect("Beranda/Admin");
				}
				elseif ($this->session->userdata('level')=='1') {
					redirect("Beranda/User");
				}

			}	
		}
		else {
			$this->session->set_flashdata('infopass', '&nbsp;');
			redirect("user");
		}
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect("user");
	}
}
?>