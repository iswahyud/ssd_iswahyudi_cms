<?php
session_start();
class Sup extends CI_Controller {

	public function __construct() {
		parent::__construct();
		if ($this->session->userdata('user')=="") {
			redirect('auth');
		}
		$this->load->helper('text');
	}
	public function index() {
		$data['user'] = $this->session->userdata('user');
		$this->load->view('dashboard', $data);
	}

	public function logout() {
		$this->session->unset_userdata('user');
		$this->session->unset_userdata('level');
		$this->session->unset_userdata('verifikasi');
		session_destroy();
		redirect('auth');
	}
}
?>