<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" Content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Sistem</title>
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/login/img/jsc.png">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/login/css/login-style.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/login/css/yud.css" media="all">
    <script type="text/javascript" src="<?php echo base_url();?>assets/login/javascript/yud.min.js"></script>
</head>
<body>
<div class="imgcontainer">
<img src="<?php echo base_url();?>assets/login/img/jsc.png" alt="CodeIgniter" width="100px"><span class="version"></span>
</div>

<form method="post" action="<?php echo base_url();?>index.php/Admin/Auth/proses">
  <div class="container2">
    <span>Jakarta Smart City - CMS</span>
  </div>

  <div class="container1">
    <div class="group">      
          <input type="text" name="vuser" class="us" required>
          <span class="highlight"></span>
          <span class="bar"></span>
          <label>USERNAME</label>
    </div>
    <div class="group">      
          <input type="password" name="vpass" class="pas" required>
          <span class="highlight"></span>
          <span class="bar"></span>
          <label>PASSWORD</label>
    </div>
    <button class="btn" type="submit">LOGIN</button>
  </div>
  <br/>
  <div class="container">
  <p class="footer">Belum punya akun? |
  <a href="<?php echo base_url();?>register">Daftar Disini!</a> </p>
  </div>

</div>
</form>
  <?php 
          $errorverif = $this->session->flashdata('errorverif');
          $infakses = $this->session->flashdata('infakses');
          $infopass = $this->session->flashdata('infopass');
          $emailverif = $this->session->flashdata('emailverif');
          if($errorverif):?>
            
            <script type="text/javascript">
                swal("Gagal Verifikasi Data!","Data tidak valid","error");
            </script>

          <?php
          echo $errorverif;
          endif;

          if($infakses):?>
            
            <script type="text/javascript">
                swal("Gagal Login!","Akses Anda Ditolak","error");
            </script>

          <?php
          echo $infakses;
          endif;

          if($infopass):?>
            
            <script type="text/javascript">
                swal("Gagal Login!","email / password belum terdaftar","error");
            </script>

          <?php
          echo $infopass;
          endif;

          if($emailverif):?>
            
            <script type="text/javascript">
                swal("Gagal Login!","Email belum diverifikasi","error");
            </script>

          <?php
          echo $emailverif;
          endif;
  ?>
</body>
</html>