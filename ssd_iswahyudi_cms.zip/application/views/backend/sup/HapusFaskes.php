
<br/>

<div class="content">
          <div class="container-fluid">
              <div class="row">
                  <div class="col-md-12">
                      <div class="card">
                          
                              <div class="header">
                                  <h4 class="title">Hapus Data</h4>
                              </div>
                              <div class="content">
                                  <?=form_open('Admin/Data/hapus_faskes/'. $id);?>
                                      
                                      <input type="hidden" name="id" value="<?php echo $id;?>">

                                        <fieldset>
                                            <div class="text-center">
                                              <span>Apakah Anda Yakin Ingin Menghapus Data <b>"<?php echo $nama_faskes;?>"</b> ?</span>
                                            </div>
                                            <hr/>
                                            <div class="text-center">
                                              <button type="submit" class="btn btn-danger">Hapus</button>
                                              <a href="<?php echo base_url();?>Admin/Data/faskes"><button type="button" class="btn">Batal</button></a>
                                            </div>
                                        </fieldset>
                                    
                                      <div class="clearfix"></div>
                                  </form>
                              </div>
                          
                  </div>
              </div>
          </div>
      </div>
      
