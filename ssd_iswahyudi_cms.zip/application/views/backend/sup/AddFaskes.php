
<br/>

<div class="content">
          <div class="container-fluid">
              <div class="row">
                  <div class="col-md-12">
                      <div class="card">
                          
                              <div class="header">
                                  <h4 class="title">Tambah Data</h4>
                              </div>
                              <div class="content">
                                  <?=form_open('Admin/Data/simpan_faskes');?>
                                      
                                      <div class="row">
                                          <div class="col-md-12">
                                              <div class="form-group">
                                                  <label>Nama Faskes</label>
                                                  <input type="text" name="nama_faskes" class="form-control border-input" placeholder="Nama Faskes">
                                              </div>
                                          </div>
                                      </div>

                                      <div class="row">
                                          <div class="col-md-12">
                                              <div class="form-group">
                                                  <label>Alamat</label>
                                                    <textarea name="alamat" class="form-control border-input" rows="4" cols="50"></textarea>
                                              </div>
                                          </div>
                                      </div>

                                      <div class="row">
                                          <div class="col-md-12">
                                              <div class="form-group">
                                                  <label>Phone Number</label>
                                                  <input type="text" name="nomor_telepon" class="form-control border-input" placeholder="Phone Number">
                                              </div>
                                          </div>
                                      </div>

                                      <div class="row">
                                          <div class="col-md-12">
                                              <div class="form-group">
                                                  <label>Latitude</label>
                                                  <input type="text" name="latitude" class="form-control border-input" placeholder="Latitude">
                                              </div>
                                          </div>
                                      </div>

                                      <div class="row">
                                          <div class="col-md-12">
                                              <div class="form-group">
                                                  <label>Longitude</label>
                                                  <input type="text" name="longitude" class="form-control border-input" placeholder="Longitude">
                                              </div>
                                          </div>
                                      </div>
                                      
                                      <div class="text-center">
                                          <button type="submit" class="btn btn-info btn-fill btn-wd">Simpan</button>
                                      </div>
                                      <div class="clearfix"></div>
                                  </form>
                              </div>
                          
                  </div>
              </div>
          </div>
      </div>
      