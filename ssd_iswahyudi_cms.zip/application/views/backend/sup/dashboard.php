
        <div class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="header">
                        <h3 class="title">Jakarta Smart City - CMS</h3>
                        <p>Aplikasi Content Management System untuk Dashboard Jakarta Smart City.</p>
                        <br/>
                    </div>
                </div>
            </div>
        </div>
