
        <div class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="header">
                        
                        <?php
                        $rows = 1;
                        foreach ($hasil as $d) :?>

                        <h3 class="title"><?php echo $d->judul ;?></h3>
                            <p class="category"></p>
                            <br/>
                            <?php echo $d->deskripsi ;?>

                        <?php $rows++; endforeach;?>

                        <?php 
                        //echo $rows;
                        if($rows == 1) :?>

                            <h3 class="title">Data masih kosong</h3>

                        <?php endif;?>
                        <br/>
                    </div>
                </div>
            </div>
        </div>
