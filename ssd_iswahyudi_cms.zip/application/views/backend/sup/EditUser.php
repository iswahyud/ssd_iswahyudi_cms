
<br/>

  <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            
                                <div class="header">
                                    <h4 class="title">Edit Data</h4>
                                </div>
                                <div class="content">
                                    <?=form_open('Admin/Data/proses_user/'. $id);?>
                                        
                                        <input type="hidden" name="id" value="<?php echo $id;?>">

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Username</label>
                                                    <input type="text" name="username" value="<?php echo $username;?>" class="form-control border-input" placeholder="Username" readonly="true">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Phone Number</label>
                                                    <input type="text" name="phone_number" value="<?php echo $phone_number;?>" class="form-control border-input" placeholder="Phone Number">
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-info btn-fill btn-wd">Update</button>
                                        </div>
                                        <div class="clearfix"></div>
                                    </form>

                                    <?php 
                                    $error = $this->session->flashdata('error');
                                    $notavailable   = $this->session->flashdata('notavailable');

                                    
                                    if($error):?>
                                        
                                        <script type="text/javascript">
                                            swal("Gagal Daftar!","Data tidak valid","error");
                                        </script>

                                    <?php
                                    echo $error;
                                    endif;                       

                                    if($notavailable):?>
                                        
                                        <script type="text/javascript">
                                            swal("Gagal Update!","Username tidak tersedia","error");
                                        </script>

                                    <?php
                                    echo $notavailable;
                                    endif;
                            ?>
                            
                                </div>
                            
                    </div>
                </div>
            </div>
        </div>
        
