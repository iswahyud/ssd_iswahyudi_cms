<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" Content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register :: Jakarta Smart City</title>
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/login/img/jsc.png">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/login/css/login-style.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/login/css/yud.css" media="all">
    <script type="text/javascript" src="<?php echo base_url();?>assets/login/javascript/yud.min.js"></script>
</head>
<body>
<div class="imgcontainer">
<img src="<?php echo base_url();?>assets/login/img/jsc.png" alt="CodeIgniter" width="100px"><span class="version"></span>
</div>

<form id="form1">
  <div class="container2">
    <span>Jakarta Smart City</span>
  </div>

  <div class="container1">
    <div class="group" style="text-align:center; font-weight: bold;">      
          Pendaftaran Berhasil!<br/>
          Silahkan cek email untuk melengkapi pendaftaran.
          <br/>
          <br/>
    </div>
    
  </div>
  <br/>
  <div class="container">
  <p class="footer">
  <a href="<?php echo base_url();?>operator" class="btn">Kembali ke Halaman Login!</a>
  </p>
  <br/>
  </div>

</div>
</form>
 <?php 
          $info = $this->session->flashdata('info');
          
          if($info):?>
            
            <script type="text/javascript">
                swal("Berhasil!","Silahkan Cek Email","success");
            </script>

          <?php
          echo $info;
          endif;

  ?>
</body>
</html>