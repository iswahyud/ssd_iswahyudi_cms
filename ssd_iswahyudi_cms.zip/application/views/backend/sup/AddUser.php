
<br/>

  <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            
                                <div class="header">
                                    <h4 class="title">Tambah Data</h4>
                                </div>
                                <div class="content">
                                    <?=form_open('Admin/Data/simpan_user');?>
                                        

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Username</label>
                                                    <input type="text" name="username" class="form-control border-input" placeholder="Username">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Phone Number</label>
                                                    <input type="text" name="phone_number" class="form-control border-input" placeholder="Phone Number">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Password</label>
                                                    <input type="password" name="pass1" class="form-control border-input">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Re-Type Password</label>
                                                    <input type="password" name="pass2" class="form-control border-input">
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-info btn-fill btn-wd">Simpan</button>
                                        </div>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            
                    </div>
                </div>
            </div>
        </div>
        