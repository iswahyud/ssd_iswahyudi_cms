<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" Content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register :: Jakarta Smart City</title>
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/login/img/jsc.png">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/login/css/login-style.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/login/css/yud.css" media="all">
    <script type="text/javascript" src="<?php echo base_url();?>assets/login/javascript/yud.min.js"></script>
</head>
<body>
<div class="imgcontainer">
<img src="<?php echo base_url();?>assets/login/img/jsc.png" alt="CodeIgniter" width="100px"><span class="version"></span>
</div>

<?=form_open('Admin/Register/proses');?>
  <div class="container2">
    <span>Jakarta Smart City</span>
  </div>

  <div class="container1">
    <div class="group">      
          <input type="text" name="username" class="us" required>
          <span class="highlight"></span>
          <span class="bar"></span>
          <label>USERNAME</label>
    </div>
    <div class="group">      
          <input type="text" name="phone_number" class="pas" required>
          <span class="highlight"></span>
          <span class="bar"></span>
          <label>PHONE NUMBER</label>
    </div>
    <div class="group">      
          <input type="password" name="pass1" class="pas" required>
          <span class="highlight"></span>
          <span class="bar"></span>
          <label>PASSWORD</label>
    </div>
    <div class="group">      
          <input type="password" name="pass2" class="pas" required>
          <span class="highlight"></span>
          <span class="bar"></span>
          <label>RE-TYPE PASSWORD</label>
    </div>
    <button class="btn" type="submit">REGISTER</button>
  </div>
  <br/>
  <div class="container">
  <p class="footer">Sudah punya akun? |
  <a href="<?php echo base_url();?>operator">Masuk Disini!</a> </p>
  </div>

</div>
</form>
  <?php 
          $info = $this->session->flashdata('info');
          $error_dft = $this->session->flashdata('error_dft');
          $infopass = $this->session->flashdata('infopass');
          $nomatch  = $this->session->flashdata('nomatch');
          $emailnotvalid  = $this->session->flashdata('emailnotvalid');
          $notavailable   = $this->session->flashdata('notavailable');

          if($info):?>
            
            <script type="text/javascript">
                swal("Berhasil!","Data tersimpan","success");
            </script>

          <?php
          echo $info;
          endif;

          if($error_dft):?>
            
            <script type="text/javascript">
                swal("Gagal Daftar!","Data tidak valid","error");
            </script>

          <?php
          echo $error_dft;
          endif;

          if($infopass):?>
            
            <script type="text/javascript">
                swal("Gagal Login!","username / password belum terdaftar","error");
            </script>

          <?php
          echo $infopass;
          endif;

          if($nomatch):?>
            
            <script type="text/javascript">
                swal("Gagal Daftar!","Password 1 & 2 harus sama","error");
            </script>

          <?php
          echo $nomatch;
          endif;

          if($notavailable):?>
            
            <script type="text/javascript">
                swal("Gagal Daftar!","Username tidak tersedia","error");
            </script>

          <?php
          echo $notavailable;
          endif;
  ?>
</body>
</html>