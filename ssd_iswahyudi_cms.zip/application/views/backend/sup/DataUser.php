                
    <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title"></h4>
                                <p class="category">
                                <a href="<?php echo base_url();?>Admin/Data/tambahuser"><button class="btn btn-success">Tambah <i class="fa fa-plus"></i></button></a>
                                </p>
                            </div>
                            <div class="content table-responsive table-full-width">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>#</th>    
                                                <th>Username</th>
                                                <th>Nomor Telepon</th>
                                                <th colspan="2">Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                            $c = 1;
                                            foreach ($hasil as $data) : ?>
                                           
                                            <tr class="odd gradeX">
                                                <td><?php echo $c;?></td>
                                                <td><?php echo $data->username;?></td>
                                                <td><?php echo $data->phone_number;?></td>
                                                <td class="center">
                                                    <a href="<?php echo base_url();?>Admin/Data/edituser/<?php echo $data->id;?>"><button class="btn btn-warning btn-mini">Edit</button></a>
                                                </td>
                                                <td class="center">
                                                    <a href="<?php echo base_url();?>Admin/Data/hapususer/<?php echo $data->id;?>"><button class="btn btn-danger btn-mini">Hapus</button></a>
                                                </td>
                                            </tr>
                                            <?php $c++; endforeach; ?>
                                        </tbody>
                                    </table>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>     
