<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_security extends CI_Model {

	function getSecSup()
	{
		$username = $this->session->userdata('id');
		
		if(empty($username))
		{
			$this->session->sess_destroy();
			redirect(site_url('operator'));
		}
		
	}

	function getSec()
	{
		$username = $this->session->userdata('id');
		
		if(empty($username))
		{
			$this->session->sess_destroy();
			redirect(site_url('operator'));
			/*redirect(site_url('user'));*/
		}
		
	}

	function logSecSup()
	{
		$role = $this->session->userdata('level');
		if($role == '2')
		{
			$this->session->sess_destroy();
			redirect(site_url('operator'));
		}
	}

	function logSec()
	{
		$role = $this->session->userdata('level');
		if($role != '1')
		{
			$this->session->sess_destroy();
			redirect(site_url('user'));
		}
	}
}
/* End of file model_security.php */
/* Location: ./application/models/model_security.php */