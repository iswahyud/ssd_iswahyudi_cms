<?php
class Login_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function proses_login()
	{
		$xuser=$this->input->post("vuser");
		$xpass=$this->input->post("vpass");
		$xmd=md5($xpass);
		$db="SELECT * FROM jsc_auth WHERE username='$xuser' and `password`='$xmd'";
		$hasil=$this->db->query($db);
		return $hasil;
	}

	public function cek_user($data) {
			$query = $this->db->get_where('jsc_auth', $data);
			return $query;
		}

}