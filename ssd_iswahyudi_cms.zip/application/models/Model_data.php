<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_data extends CI_Model {

	//User

	function checkuserByUsername($user)
	{
		 $tampil="select ifnull(id,0) from jsc_auth where username = '$user'";  
		 $hasil=$this->db->query("$tampil");
		 return $hasil;
	}

	function DataUser()
	{
		$query = $this->db->order_by('id','asc')
						  ->get('jsc_auth');
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else
		{
			return array();
		}
	}

	function AddUser($user = array())
	{
		$insert = $this->db->insert('jsc_auth', $user);
        if($insert)
        {
            return $this->db->insert_id();
        }
        else
        {
            return false;    
        }
	}

	function edituser($id)
	{
		 $tampil="select * from jsc_auth where id='$id'";  
		 $hasil=$this->db->query("$tampil");
		 return $hasil;
	}

	function prosesuser($id, $data)
	{
		 $this->db->where('id',$id)
				  ->update('jsc_auth',$data);
	}

	function hapususer($id)
	{
		 $del="delete from jsc_auth where id='$id'";
		 $hasil=$this->db->query("$del");
		 return $hasil;	
	}

	//Faskes
	function DataFaskes()
	{
		$query = $this->db->order_by('id','asc')
						  ->get('jsc_faskes');
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else
		{
			return array();
		}
	}

	function AddFaskes($user = array())
	{
		$insert = $this->db->insert('jsc_faskes', $user);
        if($insert)
        {
            return $this->db->insert_id();
        }
        else
        {
            return false;    
        }
	}

	function editfaskes($id)
	{
		 $tampil="select * from jsc_faskes where id='$id'";  
		 $hasil=$this->db->query("$tampil");
		 return $hasil;
	}

	function prosesfaskes($id, $data)
	{
		 $this->db->where('id',$id)
				  ->update('jsc_faskes',$data);
	}

	function hapusfaskes($id)
	{
		 $del="delete from jsc_faskes where id='$id'";
		 $hasil=$this->db->query("$del");
		 return $hasil;	
	}

}